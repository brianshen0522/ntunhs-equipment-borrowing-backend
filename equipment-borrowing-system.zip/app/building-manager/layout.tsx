import type React from "react"

export default function BuildingManagerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
